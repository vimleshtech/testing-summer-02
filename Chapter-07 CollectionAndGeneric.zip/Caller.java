package testcases;

public class Caller {

	public static void main(String[] args) {

		
		Employee e = new Employee();
		e.newEmployee();
		e.show();
		
		
		//arary of object
		Employee o[] = new Employee[1];
		
		for(int i=0; i<o.length;i++)
		{
			o[i] = new Employee();
			o[i].newEmployee();
			
		}
		
		for(Employee x : o)
			x.show();
		
		
	}

}
