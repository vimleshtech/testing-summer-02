package testcases;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CollectionAndGeneric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//collection : is list of dynamic data (type, and size)
		
		
		
		ArrayList al  = new ArrayList();
		al.add(11);
		al.add("nitin");
		al.add(true);
		
		System.out.println(al.size()); //print length 
		System.out.println(al.get(0));  //read first element
		
		al.remove(1) ;//remove 2nd item
		
		for(int i=0; i<al.size();i++)
			System.out.println(al.get(i)); //read one by one 
		
		
		
		//generic: dynamic size , fix type 
		ArrayList<String> l = new ArrayList<>();
		l.add("name");
		l.add("ksfjhfjghf");
		l.add("ksfjhfjghf");
		l.add("ksfjhfjghf");
		
		for(int i=0; i<l.size();i++)
			System.out.println(l.get(i)); //read one by one 
		
		
		
		//wap to get count of every value in list 
		// a, b ,a , c, a , a,a 
		ArrayList<String> BK =  new ArrayList<>();
		BK.add("a");
		BK.add("b");
		BK.add("c");
		BK.add("a");
		BK.add("a");
		BK.add("z");
		BK.add("z");
		BK.add("m");
		
		int c=0;
		int c1=0;
		int c2=0;
		
		String ss[] = new String[BK.size()];
		
		int i=0;
		
		for(int n=0;n<BK.size();n++)
		{
			
			int flag  =0;
			
			for(int j = 0; j<ss.length;j++)
			{
				if(ss[j]!=null)
				if(ss[j].equals(BK.get(n)))
					flag = 1;
			}
			
			if(flag == 0)
			{
				ss[i]= BK.get(n);
				i++;
			}
			
		}
		
		for(int n=0;n<ss.length;n++)
		{
			c =0;
			
			if(ss[n]!=null)
			{	
			for(int x=0;x<BK.size();x++)
			{		
				if(ss[n].equals(BK.get(x)))					
				{
						c++;
				}
			}
			System.out.println("count of "+ss[n]+"is "+ c);
			
			}
		}
		
		
		
		
	}

}

