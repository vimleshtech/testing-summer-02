package testcases;

import java.util.Scanner;

public class Employee {

	int pan;
	char name[] = new char[20];	
	float income;
	float tax;
	
	public void newEmployee() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter pan");
		pan = sc.nextInt();
				
		System.out.println("enter name");
		name= sc.next().toCharArray();
				
		System.out.println("enter income");
		income= sc.nextFloat();
		
		System.out.println("enter tax");
		tax= sc.nextFloat();	
		
	}
	public void show() {
		
		System.out.println("pan is "+pan);
		
		System.out.print("name is ");
		
		for(int i=0;i<name.length;i++)
			System.out.print(name[i]);
		
		System.out.println();
		System.out.println("income is "+income);
		System.out.println("tax is "+tax);
		
	}
	
}
