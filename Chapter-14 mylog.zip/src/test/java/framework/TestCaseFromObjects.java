package framework;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import objects.ReadObject;

public class TestCaseFromObjects {
	private final static Logger logger = Logger.getLogger(TestCaseFromObjects.class);
	
	Properties prop =null; 
	WebDriver driver = null;
	
	@Test
	public void login() {
		logger.debug("in login test");
		
		driver.findElement(By.id(prop.getProperty("uname"))).sendKeys("ff");
		driver.findElement(By.id(prop.getProperty("pwd"))).sendKeys("ff");
		
		driver.findElement(By.id(prop.getProperty("bt"))).click();
		logger.debug("in before test");
		
						
	}
	
	@BeforeTest
	public void loadData() {
		logger.debug("in before test");
		
		prop = ReadObject.readObjects();
		driver= new ChromeDriver();
		driver.get(prop.getProperty("url"));
		logger.debug("reader data is object");
				
	}
}
