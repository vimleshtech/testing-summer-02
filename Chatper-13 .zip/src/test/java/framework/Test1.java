package framework;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {

	public static WebDriver driver = null;
	
	@Test
	public void testA() {
		System.out.println("test1");
		
		driver.findElement(By.name("q")).sendKeys("test");
		driver.findElement(By.name("q")).click();
		
		List<WebElement> el  = driver.findElements(By.tagName("a"));

		for(WebElement e : el)
			System.out.println(e.getText());
		
	}
	@Test
	public void testB() {
		System.out.println("test2");
		driver.findElement(By.name("q")).sendKeys("selenium");
		driver.findElement(By.name("q")).click();
		
		List<WebElement> el  = driver.findElements(By.tagName("a"));

		for(WebElement e : el)
			System.out.println(e.getText());
	}
	
	@Test
	public void testC() {
		System.out.println("test3");
		driver.findElement(By.name("qa")).sendKeys(".net");
		driver.findElement(By.name("q")).click();
		
		List<WebElement> el  = driver.findElements(By.tagName("a"));

		for(WebElement e : el)
			System.out.println(e.getText());
		
	}
	@Ignore
	@Test
	public void testD() {
		System.out.println("test4");
		driver.findElement(By.name("q")).sendKeys("naukri.com");
		driver.findElement(By.name("q")).click();
		
		List<WebElement> el  = driver.findElements(By.tagName("a"));

		for(WebElement e : el)
			System.out.println(e.getText());
		
	}
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		System.out.println("before class");
		driver = new ChromeDriver();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("after class");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("before test");
		driver.get("https://google.com/");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("after test");
		
		//driver.quit();
	}

	

}
