package testngexample;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class DataProviderExample {
	
	
  @Test(dataProvider = "dp")
  public void f(String name, String email, String pwd) {
  
	  
	  System.out.println(name+"\t"+email+"\t"+pwd);
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://erp.techvisionit.com/");
	  
	  driver.findElement(By.id("txtUserName")).sendKeys(email);
	  driver.findElement(By.id("txtPassword")).sendKeys(pwd);
	  
	  driver.findElement(By.id("btnSubmit")).click();
  
  }
/*
  @DataProvider
  public Object[][] dp() {
  
  return new Object[][] 
	  {
	      new Object[] { "nitin", "nitin01@gmail.com","aff" },
	      new Object[] { "nitin11", "nitin12@gmail.com","ggfff" },
	      new Object[] { "nitin22", "nitin90@gmail.com","ddd" },
	      new Object[] { "nitin333", "nitin06@gmail.com","ff" },
	  };

    
  }*/
  
  @DataProvider
  public Object[][] dp() {
	  
	  Object[][] o= ReadExcel.readExcel();
	  return o;
	  
	  
  }
  
	  
}
