package testngexample;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ReadExcel {

	public static String[][] readExcel() 
	{
		// TODO Auto-generated method stub
		String data[][] = null;
		
		try {
			
			///read the file 
			FileInputStream fs= new FileInputStream("C:\\Users\\Tech Vision\\Desktop\\password.xls");
			//convert to excel obbject
			HSSFWorkbook book = new HSSFWorkbook(fs);
			
			HSSFSheet sheet = book.getSheet("Sheet1");
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets();
			System.out.println(sc);
			
			rc = sheet.getPhysicalNumberOfRows();
			System.out.println(rc);
			
			cc = sheet.getRow(0).getPhysicalNumberOfCells();
			System.out.println(cc);
			
			//allocate the size of array
			data = new String[rc-1][cc];
			
			String s1,s2,s3;
			for(int i=1; i<rc;i++) {
				
				HSSFRow row = sheet.getRow(i);
				
				HSSFCell cell = row.getCell(0);
				s1 = cell.getStringCellValue();
				
				cell = row.getCell(1);
				s2 = cell.getStringCellValue();
				
				cell = row.getCell(2);
				s3 = cell.getStringCellValue();
				
				
				System.out.println(s1+"\t"+s2+"\t"+s3);
				data[i-1][0] = s1;
				data[i-1][1] = s2;
				data[i-1][2] = s3;
				
				
			}
			
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}

		return data;
	}

}
