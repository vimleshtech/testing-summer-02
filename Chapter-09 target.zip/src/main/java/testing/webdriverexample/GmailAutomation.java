package testing.webdriverexample;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class GmailAutomation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		WebDriver web = new ChromeDriver();
		web.get("https://www.google.com");
		
		web.findElement(By.linkText("Gmail")).click();
		web.findElement(By.linkText("Sign in")).click();
		
		web.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		Set<String> wins = web.getWindowHandles();
		
		System.out.println(wins.size());
		for(String win : wins) {
			web.switchTo().window(win);
			
			if(web.getTitle().equals("Gmail")) {
		
				web.findElement(By.id("identifierId")).sendKeys("kapoorsonu66@gmail.com");
				web.findElement(By.id("identifierNext")).click();
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				web.findElement(By.name("password")).sendKeys("sadofs");
				
			}
			
		}
		
		
		web.navigate().back();
		web.navigate().refresh();
		web.navigate().forward();
		
		//web.close();
		web.quit();
		
		
		
		
	}

}
