package testing.webdriverexample;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class firstwebdriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.get("https://yahoo.com");
		//System.out.println("hello");
		String tit = driver.getTitle();
		String str = driver.getCurrentUrl();
		System.out.println(str);
		System.out.println(tit);
		
	List<WebElement> els=	driver.findElements(By.tagName("a"));
	
	
	for(WebElement el:els)
	{
		System.out.println(el.getText());
	}
	
	System.out.println(els.size());
	
		
		

	}

}
