package day06;

public interface Ib {

	void tax(int amt);
}
