package day06;

public class ABExtends extends Abclass {

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a*b);
	}

	@Override
	void div(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a/b);
		
	}

	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
		
	}

}
