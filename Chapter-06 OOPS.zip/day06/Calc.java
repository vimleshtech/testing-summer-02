package day06;

public class Calc {

	
	final int limit=1;
	
	int a;
	static int b;
	
	void welcome() {
		System.out.println("in parent - clac");
	}
	static void add(int x, int y) {
		System.out.println(x+y);
	}
	
	void mul(int a, int b) {
		
		//limit =0;
	
		this.a =a;
		
		if(a<limit || b<limit)
		{
			System.out.println("value cannot be 0");
		}
		else {
			System.out.println(a*b);
		}
	}
		
	void add(int a, int b , int c ) {
		System.out.println(a+b+c);
	}
}
