package day06;

public class IClass implements IA,Ib {
	
	@Override
	public void tax(int amt) {
		// TODO Auto-generated method stub

		System.out.println(amt);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a+b);
	}

	@Override
	public void add(int a, int b, int c) {
		// TODO Auto-generated method stub
		System.out.println(a+b+c);
		
	}

	@Override
	public void add(double a, double b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void div(int a, int b) {
		// TODO Auto-generated method stub
		
	}

}
