package day06;

public class Abcaller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ABExtends e = new ABExtends();
		e.add(11, 2);
		e.sub(21, 3);
		
	}

}
