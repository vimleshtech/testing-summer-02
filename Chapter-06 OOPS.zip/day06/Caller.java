package day06;

public class Caller {

	void test()
	{
		System.out.println("test");
	}
	static void test2()
	{
		System.out.println("test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calc c1 = new Calc();
		Calc c2 = new Calc();
		
		c1.a =11;
		c2.a =22;
		
		c1.b =10;
		c2.b =0;  //b is static so data will be overwrite on all previous memory 
		
		System.out.println(c1.a);//11
		System.out.println(c1.b);//0
		
		System.out.println(c2.a);//22
		System.out.println(c2.b);//0
		
		
		///
		Calc.add(11, 2);
		//Calc.mul(3, 4); //error 
		
		
		
		//create object of child class
		Dcalc dc = new Dcalc();
		dc.add(1,2);
		dc.sub(1,2);
		dc.mul(0,2);
		
		dc.add(11.33, 4);
		dc.add(11,33, 44);
		
		
		//
		Caller o = new Caller();
		o.test();
		test2();
		//test();
		
		
		//overriding 
		Calc o1 = new Calc();
		o1.welcome();  //parent 
		
		Dcalc o2 = new Dcalc();
		o2.welcome(); //child
		
		
		o1 =o2; //overriding 
		o1.welcome(); //child 
		
		
		//or
		Calc o3 = new Dcalc();
		o3.welcome();
		
		
		
	}

}
