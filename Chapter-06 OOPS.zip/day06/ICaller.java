package day06;

public class ICaller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 IA  o = new IClass();
		 o.add(11.3, 343.);
		 
	}

}
