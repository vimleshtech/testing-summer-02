package day06;

public interface IA {

	
	void add(int a, int b) ;
	void add(int a, int b, int c) ;
	void add(double a, double b) ;
	void div(int a, int b) ;
	
}
