package day06;

import javax.sound.midi.Soundbank;

public class Dcalc extends Calc {
	

	void welcome() {
		System.out.println("in child - dclac");
	}
	
	void sub(int a, int b) {
		System.out.println(a-b);
		
	}

	void add(double a, int b) {
		System.out.println(a+b);
	}
}
