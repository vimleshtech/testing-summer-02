package day06;

public abstract class Abclass {
	
	
	void add(int a, int b)
	{
		System.out.println(a+b);
	}

	abstract void mul(int a, int b);
	abstract void div(int a, int b);
	abstract void sub(int a, int b);
	
}
