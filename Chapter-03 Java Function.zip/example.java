package day03;

public class example {

	public static void main(String[] args)
	{		
		int o = functiona(4);
		System.out.println(o);
		
	}

	static int functiona(int a)
	{
		if(a%2 == 0)
		{
			return 1;
			//System.out.println("df");
		}
		else 
		{
			return 0;
		}
		
	}
}
