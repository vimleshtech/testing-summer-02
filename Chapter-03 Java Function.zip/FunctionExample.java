package day03;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) {

		
		welcome();
		welcome();

		int a,b;
		a = get_data();
		b = get_data();
		System.out.println(a*b);
		
		int o = add(a, b);
		System.out.println(o);
		
		sub(a,b);
		
		int n = fact(5);
		System.out.println(n);
		
		
	}

	//no argument , no return 
	static void welcome() {
		System.out.println("hello function ");
	}
	
	//no argument with return 
	static int get_data() {
		Scanner s =new Scanner(System.in);
		int n;
		System.out.println("enter data ");
		n = s.nextInt();
		return n;
		
	}
	
	//argument with return 
	static int add(int a, int b) {
		return a+b;
	}
	
	//argument with no return
	static void sub(int x, int y) {
		System.out.println(x-y);
	}
	
	//recussive
	static int fact(int x)
	{
		if (x ==1)
			return x;
		else
			return x*fact(x-1);
		
	}
}
