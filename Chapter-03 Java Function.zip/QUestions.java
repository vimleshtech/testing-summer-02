package day03;

public class QUestions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String s ="RAJAT";
		
		for(int i=0;i<s.length();i++) {
			
		
			System.out.println(s.substring(0, i+1));
			
			
		}
		

		String ss[] = {"R","A","J","A","T"};
		String word="";
		for(String c : ss) {
			
			word+=c; //i =1   
			//i+=10; or i = i+10
			System.out.println(word);
			
			
		}
		
	}

}
