package day05_oops;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//here e is an object of class
		Employee e = new Employee();
		
		e.showEmployee();
		//call or invoke to function/method
		e.newEmployee();
		e.showEmployee();
		
		
		Employee e2 = new Employee("Jatin");
		e2.showEmployee();
		
		
		//Copy constructor: to take one data to another object 
		Employee eo = new Employee(e);
		eo.showEmployee();
		
	}

}
