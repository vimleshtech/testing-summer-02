package day05_oops;

import java.util.Scanner;

//class
public class Employee {

	
	//data members 
	int eid;
	String name;
	String address;
	
	//without parameter
	Employee(){
		System.out.println("Object is created");
		eid =0;
		name="Default";
		address="NA";
		
				
	}
	
	//with parameter
	Employee(String name){
		System.out.println("Object is created");
		eid =0;
		this.name=name; //this is keyword which access to gloabl variable
		
		address="NA";		
	}
	
	//copy constructor
	Employee(Employee o){
		this.eid = o.eid;
		this.name = o.name;
		this.address = o.address;
	}
	//methods/functions 
	public void newEmployee()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter eid :");
		eid = sc.nextInt();
		
		System.out.println("enter name :");		
		name= sc.next();
		
		System.out.println("enter add :");
		address = sc.next();
		
		
	}
	public void showEmployee()
	{
		System.out.println("id is "+eid);
		System.out.println("name is "+name);
		System.out.println("address is "+address);
		
		
	}
}
