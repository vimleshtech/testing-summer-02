package objects;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ReadObject {
	
	private final static Logger logger = Logger.getLogger(ReadObject.class);
	
	public static Properties readObjects() {
		logger.debug("-----code is stared..---");
		logger.debug("code is stared..");
		
		Properties prop =new Properties();
		try
		{
		
			FileInputStream fs = new FileInputStream("C:\\Users\\Tech Vision\\eclipse-workspace\\firstmaven\\src\\test\\java\\objects\\Objects.properties");
			logger.debug("code is loaded..");
				
			
			prop.load(fs);
			logger.debug("converted to propertied..");
			
			
		}
		catch (Exception e) {
			// TODO: handle exception
			
			logger.error(e.toString());
			
		}
		logger.debug("end of code");
		return prop;

	}

}
