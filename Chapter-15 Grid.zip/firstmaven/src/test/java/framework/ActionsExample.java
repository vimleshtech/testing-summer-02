package framework;

import static org.junit.Assert.*;
import static org.testng.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsExample {

	static WebDriver driver = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		driver = new ChromeDriver();
		driver.get("https://google.com/");
		
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testB() {
		String t = driver.getTitle();
		Assert.assertEquals("Search Resule", t);//expected,actual 
		
	}
	
	@Test
	public void testC() {
	
		try
		{
			int a,b,c;
			a =44;
			b =0;
			c =a/b;
			System.out.println(c);
			
		}
		catch (Exception e) {
			// TODO: handle exception
			
			fail(e.toString());
			
			//System.out.println(e.toString());
		}
	}
	
	
	@Test
	public void testA() {
	
	
	String t = driver.getTitle();
	Assert.assertEquals("Google", t);//expected,actual 
	
		
	 WebElement q = 	driver.findElement(By.name("q"));
	 q.sendKeys("test");
	 
	 q.submit();
	 
	 
	//driver.findElement(By.name("btnK")).click();
	
	 
	//Actions act = new Actions(driver);
	 //act.moveToElement(q).build().perform();
	 
	 

	
			 
		
	}

}
