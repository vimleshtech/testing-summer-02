package day02;

import java.util.Scanner;

public class WhileLoop {

	public static void main(String[] args) {
		
		
		int i=1;
		while(i<10) {
			System.out.print(i);
			i++;
		}
		
		System.out.println();
		//print in reverse order
		i =10;
		while(i>0) {
			System.out.println(i);
			i--;
		}

		//wap to get sum of all even and odd numbers between two given range
		int n1,n2,se=0,so=0;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter start range ");
		n1 = sc.nextInt();
		
		System.out.println("enter end range ");
		n2 = sc.nextInt();
		
		while(n1<=n2) {
			
			if(n1%2 ==0) {
				se+=n1;
			}
			else {
				so+=n1;
			}
			n1++;
		}
		System.out.println("sum of all even no "+se);
		System.out.println("sum of all odd no "+so);
		
		
		
		
		
	}

}
