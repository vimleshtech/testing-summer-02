package day02;

public class SingleDimenssionArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name[] = new String[3];
		name[0] ="Raman";
		name[1] ="Jatin";
		name[2] ="Divya";
		//name[3] ="Divya";
		
		
		System.out.println(name[1]);
		
		
		for(String s: name)		
			System.out.println(s);
		
		//
		int n[] = {11,22,44,5};
		for(int s: n)		
			System.out.println(s);
		
				
	}

}
