package day02;

public class AdvanceLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int n[] = {111,222,3,44,23};
		
		for(int x: n) {
			System.out.println(x);
		}
	}

}
