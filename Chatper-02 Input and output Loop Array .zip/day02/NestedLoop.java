package day02;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1;i<4;i++)
		{
			for(int x =1; x<4;x++) {
							
				System.out.print(x);
			}
			System.out.println();
			
		}
		
		
		//
		/*
		 * 1
		 * 12
		 * 123
		 */
		
		for(int i=1;i<6;i++)
		{
			for(int x =1; x<=i;x++) {
							
				System.out.print(x);
			}
			System.out.println();
			
		}
		
		
		
	}

}
