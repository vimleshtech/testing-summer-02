package day02;

public class OutputExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("hi");
		System.out.println("Nitin");
		
		System.out.print("hi");
		System.out.println("Nitin");
		
		
		System.out.println();
		System.out.print("");
		
		
		System.out.print("hi \n this is my test code \t Raman");
		
		
	}

}
