package day02;

import java.util.Scanner;

public class InputExample {

	public static void main(String[] args) {

		String name;
		int n;
		float f;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter name :");
		name = s.nextLine();
		
		System.out.println("enter int/id :");
		n = s.nextInt();
		
		System.out.println("enter float/salary :");
		f = s.nextFloat();
		

		System.out.println(name);
		System.out.println(n);
		System.out.println(f);
		
		

	}

}
