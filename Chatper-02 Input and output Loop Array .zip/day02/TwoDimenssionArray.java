package day02;

public class TwoDimenssionArray {

	public static void main(String[] args) {

		
		int n[][] = {{11,22,33},{1,2,3,45},{4,3,2,2}};
		
		System.out.println(n.length);
		System.out.println(n);
		
		for(int r[] : n) {
			for(int c: r) {
				System.out.print(c);
			}
			System.out.println();
		}
		
		for(int r[] : n) {
		
			System.out.println(r[0]);
			System.out.println(r[1]);
			System.out.println(r[2]);
		}

	}

}
