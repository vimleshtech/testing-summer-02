package example;

public class DataType {

	public static void main(String[] args) {

		byte b =11;
		short s =4444;
		int i =4444432;
		long l=4433554544444443334l;
		
		float f =444.4f;
		double d =4444.3;
		
		char c ='%';
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(c);
		
			
				
		
		

	}

}
