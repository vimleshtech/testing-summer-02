package example;

public class B8 {

	public static void main(String[] arg) {
		
	
	int sal = 6000;
	
	if(sal >= 5000 && sal <= 10000)
	{
		double hra = sal*.10;//
		double da = sal*.05;
		double salb = hra+da;
		           
		System.out.print(salb);
		
	}
	
	else if(sal >= 10001  && sal <= 15000)
	{
		

		double hra = sal*.15;
		double da = sal*.08;
		double salb = hra+da;           
		System.out.print(salb);
	}
	
	else
	{
		
		System.out.print("nothing");
	}
	

}
}
