package example;

public class StringExample {

	public static void main(String[] args) {
		
		String s ="tHIS is JAVA Code";
		System.out.println(s);
		
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		System.out.println(s.length());
		System.out.println(s.replace("e", "xu"));
		
		int ps = s.indexOf("i"); //return position of i
		System.out.println(ps);
				
		//this is java code
		String ss = s.substring(2,6);
		System.out.println(ss);
		
		char c = ss.charAt(1);
		System.out.println(c);
		int n = c; //convert to ascii
		System.out.println(n);
		
		
		char cc[] = s.toCharArray();  //{'T','h','i'..}
		System.out.println(cc.length);
		
		for(int i=0; i<cc.length;i++) {
			System.out.println(cc[i]);
		}

		//split : break string by given seperator 
		String sn[] = s.split(" "); //{"this","is","java"...}
		System.out.println(sn.length); //word count
		
		for(int i=0; i<sn.length;i++) {
			System.out.println(sn[i]);
		}
		
		//
		if(s.contains("is")) {
			System.out.println("is is present");
		}
		else {
			System.out.println("is is not present");
		}
		
		
		if(s.startsWith("is")) {
			System.out.println("start with is");
		}
		else {
			System.out.println("not start with is");
		}
		
		if(s.endsWith("is")) {
			System.out.println("end with is");
		}
		else {
			System.out.println("not end with is");
		}
		
		
		if(s.equals("is")) {
			System.out.println("match");
		}
		else {
			System.out.println("not match");
		}
		
		if(s.equalsIgnoreCase("IS")) {
			System.out.println("match");
		}
		else {
			System.out.println("not match");
		}
		
		
		
	}
	

}
