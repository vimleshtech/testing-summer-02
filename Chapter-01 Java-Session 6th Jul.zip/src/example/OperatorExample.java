package example;

public class OperatorExample {

	public static void main(String[] args) {
		
		int i,j;
		i=0;
		j=0;
		
		System.out.println(i++);//0  
		System.out.println(++j);//1
		
		System.out.println(i);//1
		System.out.println(j);//1

		
		int a =10;
		a+=1;
		System.out.println(a);
				
		a*=3;
		System.out.println(a);
				
		
	}

}
