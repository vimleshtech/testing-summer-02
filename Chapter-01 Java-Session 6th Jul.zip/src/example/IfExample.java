package example;

public class IfExample {

	public static void main(String[] args) {
		
		int a,b,c;
		
		a =33;
		b =43;
		
		c =a+b;
		
		//if condition 
		//show if c is even no
		if(c%2 ==0 ) {
			System.out.println(c);
		}
		
		
		
		//if else 
		//show greater no from two inputs
		if(a>b) {
			System.out.println("a is greater");
		}
		else {
			System.out.println("b is greater");
		}

		
		//tax calculation with if else if else ....
		int amt =444;
		double tax =0;
		
		if(amt>1000) {
			tax =amt*.18;
		}
		else if(amt>500) {
			tax = amt*.12;
		}
		else if(amt >100) {
			tax = amt *.10;
		}
		else {
			tax = amt*.02;
		}
		
		System.out.println("tax amout is : "+tax);
		
		
		//neste if else 
		int n1,n2,n3;
		n1=33;
		n2 =55;
		n3 =900;
		
		
		if(n1>n2) {
			
			if(n1>n3)
			{
				System.out.println("n1 is greater");
			}
			else {
				System.out.println("n3 is greater");
			}
			
		}
		else {
			
			if(n2>n3) {
				System.out.println("n2 is greter");
			}
			else {
				System.out.println("n3 is greater");
			}
		}
		
		
		
		// using and 
		if(n1> n2 && n1>n3) {
			System.out.println("n1 is greater");
		}
		else if(n2>n1 && n2 >n3) {
			System.out.println("n2 is greater");
		}
		else {
			System.out.println("n3 is greater");
		}
	}

}
