package day04;

import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		int n,d,o;
		
		System.out.println("enter data ");
		n = s.nextInt();
		
		System.out.println("enter data ");
		d = s.nextInt();
		
		try {
		
			
				if(d<0)
				{
					ArithmeticException er = 
							new ArithmeticException("Divisor cannot be less than 0");
					
					throw er;
				}
				
				o =n/d;
				System.out.println(o);
				
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("maths error "+e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch (Exception e) {
			
			System.out.println("error");
			
		}
		finally {
			System.out.println("end of block");
		}
		o =n+d;
		System.out.println(o);
		
		
		

	}

}
