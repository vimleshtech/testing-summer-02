package day04;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FIleHandling {

	static void readFile() throws IOException {
		
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\TimeSeries.txt");		
		BufferedReader br = new BufferedReader(fr);
		
		String line = br.readLine();
		
		while(line != null) {
			System.out.println(line);
			line = br.readLine();
		}
		
		br.close();
		fr.close();
	}
	static void writeFile() throws IOException {
		
		//create new file if not exist
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\out.txt");
		
		
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write("hi, this is test file");
		bw.newLine();
		bw.write("bye");
		
		bw.close();
		fw.close();
		
		
		
		
	}
	public static void main(String[] args) throws IOException {
	
		readFile();
		writeFile();

	}

}
