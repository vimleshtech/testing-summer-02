package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pagefactory.LoginPage;
import pagefactory.RegisterPage;

public class Facebook2 {
	
   WebDriver driver = null;
   LoginPage login =null;
   RegisterPage register = null;
	
  @Test
  public void loginTest() {
  
	  
	  login = new LoginPage(driver);
	  login.loginValidate("vimlesh073@gmail.com", "fglkhfgf");
  
  }
  @Test
  public void registerTest() {
    
  
  }
  
  @BeforeTest
  public void beforeTest() {
	  
	  driver = new ChromeDriver();
	  driver.get("http://www.facebook.com/");
	  
  }
}
