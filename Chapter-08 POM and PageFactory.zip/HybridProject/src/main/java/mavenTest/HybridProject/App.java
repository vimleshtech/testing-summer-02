package mavenTest.HybridProject;

import org.apache.log4j.Logger;

/**
 * Hello world!
 *
 */
public class App 
{
	public static Logger logger = Logger.getLogger(App.class);
	
    public static void main( String[] args )
    {
    
    	logger.info("app is started");
    	
        System.out.println( "Hello World!" );
    
    
        add(11, 2);
        
        div(44,5);
        div(55,5);
        sub(25,35);
        
        logger.info("app is closed");
        	
    }
    
    
    static void add(int a, int b) {
    	
    	logger.debug("add function is started");
    	
    	System.out.println(a+b);
    	
    	logger.debug("add function is completed");
    	
    }
    
     static void div(int a, int b) 
     {
    	logger.debug("div function is started");
    	
    	try {
    		
    	int c = a/b;
    	System.out.println(c);
    	
    	}
    	catch (Exception e) {
    		logger.error(e);
        	
			// TODO: handle exception
		}
    	}
    	static void sub(int a,int b) {
    		
    		logger.debug("sub is started");
    		
    		try {
    			
    			System.out.println(a-b);	
    		}
    		
        catch(Exception e) {
        	logger.error(e);
        }
    	}
    }

