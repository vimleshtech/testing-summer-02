package pagefactory;

public class RegisterPage {

}
