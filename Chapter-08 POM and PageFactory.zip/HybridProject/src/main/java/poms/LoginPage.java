package poms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	
	WebDriver driver;
	
	By username = By.name("email");
	By userpwd = By.name("pass");
	By loginbtn = By.id("u_0_a");
		
	public LoginPage(WebDriver driver){
		this.driver = driver;
	}
	
	public void loginValidate(String user,String pwd) {
		
		driver.findElement(username).sendKeys(user);
		driver.findElement(userpwd).sendKeys(pwd);
		driver.findElement(loginbtn).click();
		
	}
	
}
