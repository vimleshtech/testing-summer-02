package poms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {

	
	WebDriver driver;
	
	By firstname = By.name("firstname");
	By lastname = By.name("lastname");
	By email = By.name("reg_email__");
	By userwd  = By.name("reg_passwd__");
	By day = By.name("birthday_day");
	By month = By.name("birthday_month");
	By year = By.name("birthday_year");
	By gender = By.id("u_0_6");
	By regbtn  = By.name("websubmit");
	
	
	public RegisterPage(WebDriver driver){
		this.driver = driver;
	}
	
	public void registerValidate(String fn,String ln, String e,String pwd,String d, String m, String y) {
		
		driver.findElement(firstname).sendKeys(fn);
		driver.findElement(lastname).sendKeys(ln);
		driver.findElement(email).sendKeys(e);
		driver.findElement(userwd).sendKeys(pwd);
		driver.findElement(day).sendKeys(d);
		driver.findElement(month).sendKeys(m);
		driver.findElement(year).sendKeys(y);
		driver.findElement(gender).click();
		driver.findElement(regbtn).click();
		
	}
	
	
	
}
