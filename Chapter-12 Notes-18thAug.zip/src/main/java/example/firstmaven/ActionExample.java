package example.firstmaven;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();		
		driver.get("");
		
		Actions act = new Actions(driver);
		WebElement e = driver.findElement(By.id(""));
		WebElement t = driver.findElement(By.id(""));
		
		act.moveToElement(e).click();
		act.moveToElement(e).build().perform(); //on focus 
		act.moveToElement(e).doubleClick();
		act.moveToElement(e).clickAndHold();
		  
		act.moveToElement(e).contextClick(); //click on current location 
		
		act.dragAndDrop(e, t);
		
		//
		int a=11;
		long l =44;
		
		a =(int) l;
		
		//Scroll 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
        js.executeScript("javascript:window.scrollBy(0,350)");
        //x,y

	}

}
