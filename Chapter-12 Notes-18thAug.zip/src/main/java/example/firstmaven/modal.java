package example.firstmaven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class modal {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver = new ChromeDriver();
		driver.get("http://boschservicepackage.com");
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("7RV8d*<n'k");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"menubar_item_SalesOrder\"]/strong")).click();
		driver.findElement(By.id("SalesOrder_listView_basicAction_LBL_ADD_RECORD")).click();
		//driver.findElement(By.xpath("//div[@id='addAgreementConditionModal']//tbody//tr//td//input[@value='new']")).click();
		Thread.sleep(3000);
		String s = 	driver.findElement(By.id("addAgreementConditionModal")).getAttribute("innerHTML");
		
		System.out.println(s);
		s = driver.findElement(By.cssSelector("#addAgreementConditionModal > div > div > div.modal-header")).getAttribute("innerHTML");
		System.out.println(s);
		
		driver.findElement(By.cssSelector("#addAgreementConditionModal > div > div > div.modal-body1 > table > tbody > tr:nth-child(1) > td:nth-child(1) > input")).click();
		driver.findElement(By.cssSelector("#modalClose")).click();
	
	}
	//div[@id='addAgreementConditionModal']//tbody//tr//td//input[@value='new']
}
