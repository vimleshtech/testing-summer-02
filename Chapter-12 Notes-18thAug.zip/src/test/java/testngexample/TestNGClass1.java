package testngexample;

import org.testng.annotations.Test;

public class TestNGClass1 {
  @Test(priority=1)
  public void f() {

	  System.out.println("f");
  
  }

  @Test(priority=0)
  public void login() {
	  System.out.println("login");
  
  }
  
  
  @Test(priority=4)
  public void logout() {
	  System.out.println("logout");
  
  }
  
  
  
  @Test(priority=2)
  public void search() {
	  System.out.println("search");
  
  }
  
  
  
  @Test(priority=3)
  public void test1() {

	  System.out.println("test1");
  }
  
}
